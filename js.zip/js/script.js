document.addEventListener('DOMContentLoaded', () => {
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const phoneInput = document.getElementById('phone');
    const subscribeBtn = document.getElementById('subscribeBtn');
    const successMessage = document.getElementById('successMessage');

  
    function validateName(name) {
        return /^[а-яА-ЯёЁa-zA-Z]+$/.test(name.trim());
    }

    
    function validateEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }

    
    function validatePhone(phone) {
        return /^\d{11}$/.test(phone);
    }

    function validateForm() {
        const isValid = validateName(nameInput.value) && 
                        validateEmail(emailInput.value) && 
                        validatePhone(phoneInput.value);
        subscribeBtn.disabled = !isValid;
        subscribeBtn.classList.toggle('disabled', !isValid);
    }

  
    function showTooltip(input, tooltip) {
        tooltip.classList.add('active-tooltip');
    }

    function hideTooltip(tooltip) {
        tooltip.classList.remove('active-tooltip');
    }

    
    nameInput.addEventListener('focus', () => showTooltip(nameInput, document.getElementById('nameTooltip')));
    nameInput.addEventListener('blur', () => hideTooltip(document.getElementById('nameTooltip')));
    nameInput.addEventListener('input', validateForm);

    emailInput.addEventListener('focus', () => showTooltip(emailInput, document.getElementById('emailTooltip')));
    emailInput.addEventListener('blur', () => hideTooltip(document.getElementById('emailTooltip')));

    emailInput.addEventListener('input', validateForm);

    phoneInput.addEventListener('focus', () => showTooltip(phoneInput, document.getElementById('phoneTooltip')));
    phoneInput.addEventListener('blur', () => hideTooltip(document.getElementById('phoneTooltip')));
    phoneInput.addEventListener('input', validateForm);

   
    document.getElementById('subscribeForm').addEventListener('submit', (e) => {
        e.preventDefault(); 
        if (!subscribeBtn.disabled) { 
            successMessage.textContent = `Спасибо за подписку, ${nameInput.value}!`;
            successMessage.style.display = 'block';
            e.target.reset(); 
            validateForm(); 
        }
    });
});